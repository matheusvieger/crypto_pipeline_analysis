import boto3
import pandas as pd
import io
import json

s3 = boto3.client('s3')
bucket_name = 'crypto-pipeline-dados-mathvieger'

def lambda_handler(event, context):
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix='raw/')

    if 'Contents' not in response:
        print("Nenhum arquivo encontrado.")
        return {
            'statusCode': 200,
            'body': 'Nenhum arquivo encontrado.'
        }

    for obj in response['Contents']:
        key = obj['Key']
        print(f"Verificando arquivo: {key}")
        
        if key.lower().endswith('.json'):
            print(f"Processando arquivo: {key}")
            s3_object = s3.get_object(Bucket=bucket_name, Key=key)
            content = s3_object['Body'].read()

            try:
                df = pd.read_json(io.BytesIO(content), lines=True)  # se for JSON Lines
            except ValueError:
                df = pd.read_json(io.BytesIO(content))  # se for JSON comum

            df['arquivo_processado'] = key

            # Define o novo caminho na trusted
            output_key = key.replace('raw/', 'trusted/').replace('.json', '.csv')

            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)

            s3.put_object(
                Bucket=bucket_name,
                Key=output_key,
                Body=csv_buffer.getvalue()
            )
        else:
            print(f"Ignorando arquivo não JSON: {key}")

    return {
        'statusCode': 200,
        'body': 'Processamento finalizado.'
    }
