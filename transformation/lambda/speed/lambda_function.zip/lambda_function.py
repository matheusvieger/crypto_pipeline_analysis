import json
import boto3
import os
from datetime import datetime
import io
import pandas as pd

s3 = boto3.client("s3")

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        chave_raw = record['s3']['object']['key']

        # Valida se é um arquivo .json dentro de 'raw/'
        if not chave_raw.startswith("raw/") or not chave_raw.endswith(".json"):
            continue

        nome_arquivo = os.path.basename(chave_raw)
        nome_cripto = nome_arquivo.split("_")[0]

        print(f"Processando novo arquivo: {nome_arquivo}")

        obj = s3.get_object(Bucket=bucket, Key=chave_raw)
        conteudo = json.loads(obj["Body"].read())

        preco = conteudo.get(nome_cripto, {}).get("usd")
        dado_transformado = {
            "cripto": nome_cripto,
            "preco_usd": preco,
            "timestamp_processamento": datetime.utcnow().isoformat()
        }

        # Converte para CSV
        df = pd.DataFrame([dado_transformado])
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)

        chave_trusted = chave_raw.replace("raw/", "trusted/").replace(".json", ".csv")

        s3.put_object(
            Bucket=bucket,
            Key=chave_trusted,
            Body=csv_buffer.getvalue(),
            ContentType="text/csv"
        )

        print(f"Arquivo transformado e salvo em: {chave_trusted}")
